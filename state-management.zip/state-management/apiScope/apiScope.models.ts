export interface ScopesItem {
    
    name: string,
    displayName:string,
    description :string,
    id: number
}

